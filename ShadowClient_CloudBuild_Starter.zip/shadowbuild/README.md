# Shadow Client Android Starter

This is a starter Android UI prototype. It does not connect to, modify, or inject into Minecraft and does not change in-game touch controls.

## Build APK in GitHub Actions (cloud)
1. Create a new GitHub repository from your browser.
2. Upload the *contents* of this ZIP to the repository (including the hidden `.github/workflows/build-apk.yml` file; on mobile, ensure hidden folders are included).
3. Open the repository's **Actions** tab and select **Build Shadow Client APK**.
4. Tap **Run workflow** and wait for it to finish successfully.
5. Open the completed run and download the `ShadowClient-debug-apk` artifact. Extract the downloaded ZIP to get the APK.

The workflow uses GitHub-hosted runners. GitHub account sign-in is required. Do not upload passwords, private keys, or personal files. Review the code before installing the APK. This debug APK is for testing only.
