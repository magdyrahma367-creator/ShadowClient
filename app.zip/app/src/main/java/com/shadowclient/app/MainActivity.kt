package com.shadowclient.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 12, 25)
    private val panel = Color.rgb(33, 24, 46)
    private val purple = Color.rgb(109, 40, 217)
    private val pale = Color.rgb(221, 214, 254)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showPage("Home")
    }

    private fun label(text: String, size: Float = 16f, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.WHITE)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, 8, 0, 8)
        }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setBackgroundColor(purple)
            setOnClickListener { action() }
        }

    private fun rowSwitch(title: String, summary: String? = null): Switch =
        Switch(this).apply {
            text = if (summary == null) title else "$title\n$summary"
            textSize = 15f
            setTextColor(Color.WHITE)
            isChecked = true
            setPadding(8, 12, 8, 12)
        }

    private fun showPage(page: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(20, 18, 20, 16)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 12)
        }
        header.addView(label("⬡  SHADOW CLIENT", 24f, true))
        header.addView(label("BEDROCK EDITION  •  PROTOTYPE 0.1", 11f))
        root.addView(header)

        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Home", "PvP HUD", "Touch").forEach { destination ->
            val b = Button(this).apply {
                text = destination
                textSize = 12f
                setTextColor(Color.WHITE)
                setBackgroundColor(if (page == destination) purple else panel)
                setOnClickListener { showPage(destination) }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, 52, 1f).apply { setMargins(2, 2, 2, 12) })
        }
        root.addView(nav)

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 4, 0, 4)
        }
        when (page) {
            "Home" -> {
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(16, 16, 16, 16)
                    setBackgroundColor(panel)
                }
                card.addView(label("ENTER THE SHADOW", 22f, true))
                card.addView(label("Your Minecraft Bedrock companion interface."))
                card.addView(label("✓ UI prototype initialized", 14f))
                card.addView(label("⚙ Minecraft integration: not connected", 14f))
                content.addView(card)
                content.addView(label("ROADMAP", 18f, true))
                content.addView(label("1. Interface\n2. Android app prototype\n3. Compatibility testing"))
            }
            "PvP HUD" -> {
                content.addView(label("PvP HUD SETTINGS", 20f, true))
                content.addView(label("These are interface previews only. No live game data is read."))
                listOf("FPS counter", "CPS counter", "Armor status", "Coordinates display").forEach {
                    content.addView(rowSwitch(it))
                }
            }
            else -> {
                content.addView(label("TOUCH SETTINGS", 20f, true))
                content.addView(label("Button size (preview only)", 15f, true))
                val sizeValue = label("100%", 14f)
                content.addView(sizeValue)
                content.addView(SeekBar(this).apply {
                    max = 60
                    progress = 30
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                            sizeValue.text = "${70 + progress}%"
                        }
                        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                    })
                })
                content.addView(label("Button opacity (preview only)", 15f, true))
                val opacityValue = label("80%", 14f)
                content.addView(opacityValue)
                content.addView(SeekBar(this).apply {
                    max = 80
                    progress = 60
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                            opacityValue.text = "${20 + progress}%"
                        }
                        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                    })
                })
                content.addView(label("Note: these settings do not change Minecraft's actual controls.", 12f))
            }
        }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(label("DEMO ONLY  •  NOT CONNECTED TO MINECRAFT", 10f))
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }
}
